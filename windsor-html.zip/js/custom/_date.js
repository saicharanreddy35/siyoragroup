jQuery(document).ready(function() {
    "use strict";
    //init date
    var mdate = new Date();
    document.getElementById('date').innerHTML = mdate.getFullYear();
    
});